// src/core/domain/entities/TraceLink.ts
import { Entity } from '../../shared/Entity';
import { AppError } from '../../shared/AppError';

// Định nghĩa Props (Dữ liệu thô)
export interface TraceLinkProps {
    fromEntityType: string; // Loại thực thể nguồn (ví dụ: "Worker", "Shift", "TappingArea")
    fromEntityId: string;   // ID của thực thể nguồn
    toEntityType: string;   // Loại thực thể đích (ví dụ: "Product", "Batch")
    toEnntityId: string;     // ID của thực thể đích
    createdAt: Date;        // Ngày tạo
}

export class TraceLink extends Entity<TraceLinkProps> {
    // Factory method: Cách tạo mới một TraceLink chuẩn business
    public static create(props: TraceLinkProps, id?: string): TraceLink {
        // Validate logic nghiệp vụ ngay khi tạo
        if (!props.fromEntityId || !props.toEnntityId) {
            throw new AppError('fromEntityId and toEnntityId are required');
        }

    }

    // Getters
    get status() { return this.props.status; }
    get latexType() { return this.props.latexType; }
    get workerId() { return this.props.workerId; }
    get shiftId() { return this.props.shiftId; }
    get tappingAreaId() { return this.props.tappingAreaId; }
    get createdAt() { return this.props.createdAt; }
    get confirmedAt() { return this.props.confirmedAt; }

    // Business Logic Methods (Domain Service sẽ gọi cái này)
    public confirm() {
        if (this.props.status === 'CONFIRMED') {
            throw new AppError('Batch is already confirmed');
        }
        this.props.status = 'CONFIRMED';
        this.props.confirmedAt = new Date();
    }
}