// src/core/domain/interfaces/IHarvestBatchRepository.ts
import { HarvestBatch } from '../entities/HarvestBatch'; // Chúng ta sẽ tạo entity này ngay sau đây

export interface IHarvestBatchRepository {
  save(batch: HarvestBatch): Promise<void>;
  findById(id: string): Promise<HarvestBatch | null>;
  exists(id: string): Promise<boolean>;
  // Thêm các method khác tùy nhu cầu nghiệp vụ, ví dụ:
  // findByWorkerId(workerId: string): Promise<HarvestBatch[]>;
}