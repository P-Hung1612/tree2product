import 'dotenv/config'; // Load .env
import express from 'express';
import { PrismaClient } from '@prisma/client';
import { PrismaHarvestBatchRepository } from './infrastructure/database/prisma/repositories/PrismaHarvestBatchRepository';
import { CreateHarvestBatchUseCase } from '@application/use_cases/CreateHarvestBatchUseCase';
import { CreateHarvestBatchController } from '@infrastructure/http/controllers/HarvestBatchController';
import { PrismaWeighedRecordRepository } from '@infrastructure/database/prisma/repositories/PrismaWeighedRecordRepository';
import { WeighBatchUseCase } from '@application/use_cases/WeighBatchUseCase';
import { CreateWeighBatchController } from '@infrastructure/http/controllers/WeighBatchController';
import { ConfirmBatchController } from '@infrastructure/http/controllers/ConfirmBatchController';
import { ConfirmBatchUseCase } from '@application/use_cases/ConfirmBatchUseCase';
import { CreateVehicleController } from '@infrastructure/http/controllers/VehicleController';
import { CreateVehicleUseCase } from '@application/use_cases/CreateVehicleUseCase';
import { PrismaVehicleRepository } from '@infrastructure/database/prisma/repositories/PrismaVehicleRepository';
import { LoadBatchToVehicleController } from '@infrastructure/http/controllers/LoadBatchToVehicleController';
import { LoadBatchToVehicleUseCase } from '@application/use_cases/LoadBatchToVehicleUseCase';
import { PrismaTraceLinkRepository } from '@infrastructure/database/prisma/repositories/PrismaTraceLinkRepository';
import { PrismaVehicleLoadRepository } from './infrastructure/database/prisma/repositories/PrismaVehicleLoadRepository';
import { CreateTankController } from '@infrastructure/http/controllers/TankController';
import { CreateTankUseCase } from '@application/use_cases/CreateTankUseCase';
import { PrismaTankRepository } from '@infrastructure/database/prisma/repositories/PrismaTankRepository';
import { ReceiveLoadToTankController } from '@infrastructure/http/controllers/ReceiveLoadToTankController';
import { ReceiveLoadToYardController } from '@infrastructure/http/controllers/ReceiveLoadToYardController';
import { ReceiveLoadToTankUseCase } from '@application/use_cases/ReceiveLoadToTankUseCase';
import { PrismaMaterialEntryRepository } from '@infrastructure/database/prisma/repositories/PrismaMaterialEntryRepository';
import { PrismaYardRepository } from '@infrastructure/database/prisma/repositories/PrismaYardRepository';
import { CreateYardUseCase } from '@application/use_cases/CreateYardUseCase';
import { CreateYardController } from '@infrastructure/http/controllers/YardController';
import { ReceiveLoadToYardUseCase } from '@application/use_cases/ReceiveLoadToYardUseCase';
import { PrismaProcessDefinitionRepository } from '@infrastructure/database/prisma/repositories/PrismaProcessDefinitionRepository';
import { AssignProductionToTankUseCase } from '@application/use_cases/AssignProductionToTankUseCase';
import { PrismaProcessInstanceRepository } from '@infrastructure/database/prisma/repositories/PrismaProcessInstanceRepository';
import { AssignProductionToTankController } from '@infrastructure/http/controllers/AssignProductionToTank';
import { PrismaChemicalRepository } from '@infrastructure/database/prisma/repositories/PrismaChemicalRepository';
import { CreateChemicalUseCase } from '@application/use_cases/CreateChemicalUseCase';
import { CreateChemicalController } from '@infrastructure/http/controllers/ChemicalController';
import { PrismaChemicalEntryRepository } from '@infrastructure/database/prisma/repositories/PrismaChemicalEntryRepository';
import { AddChemicalToProcessUseCase } from '@application/use_cases/AddChemicalToProcessUseCase';
import { AddChemicalToProcessController } from '@infrastructure/http/controllers/AddChemicalToProcessController';


//--COMPOSITION ROOT (Nơi khởi tạo và kết nối tất cả các thành phần lại với nhau)
//1. Infra
const prisma = new PrismaClient();
const harvestBatchRepo = new PrismaHarvestBatchRepository(prisma);
const vehicleRepo = new PrismaVehicleRepository(prisma);
const traceLinkRepo = new PrismaTraceLinkRepository(prisma);
const vehicleLoadRepo = new PrismaVehicleLoadRepository(prisma);
const tankRepo = new PrismaTankRepository(prisma);
const materialEntryRepo = new PrismaMaterialEntryRepository(prisma);
const yardRepo = new PrismaYardRepository(prisma);
const processDefRepo = new PrismaProcessDefinitionRepository(prisma);
const processInsRepo = new PrismaProcessInstanceRepository(prisma);
const chemRepo = new PrismaChemicalRepository(prisma);
const chemicalEntryRepo = new PrismaChemicalEntryRepository(prisma);
//2. Use Cases
const createBatchUseCase = new CreateHarvestBatchUseCase(harvestBatchRepo);
const createWeighBatchUseCase = new WeighBatchUseCase(harvestBatchRepo, new PrismaWeighedRecordRepository(prisma));
const confirmBatchUseCase = new ConfirmBatchUseCase(harvestBatchRepo);
const createVehicleUseCase = new CreateVehicleUseCase(vehicleRepo);
const loadBatchToVehicleUseCase = new LoadBatchToVehicleUseCase(vehicleLoadRepo, harvestBatchRepo, traceLinkRepo);
const createTankUseCase = new CreateTankUseCase(tankRepo);
const receiveLoadToTankUseCase = new ReceiveLoadToTankUseCase(traceLinkRepo, tankRepo, materialEntryRepo, vehicleLoadRepo);
const createYardUseCase = new CreateYardUseCase(yardRepo);
const receiveLoadToYardUseCase = new ReceiveLoadToYardUseCase(traceLinkRepo, yardRepo, materialEntryRepo, vehicleLoadRepo);
const assignProductionToTankUseCase = new AssignProductionToTankUseCase(tankRepo, processDefRepo, processInsRepo);
const createChemicalUseCase = new CreateChemicalUseCase(chemRepo);
const addChemicalToProcessUseCase = new AddChemicalToProcessUseCase(chemRepo, tankRepo, processInsRepo, chemicalEntryRepo);
//3. Controllers
const createBatchController = new CreateHarvestBatchController(createBatchUseCase);
const createWeighBatchController = new CreateWeighBatchController(createWeighBatchUseCase);
const confirmBatchController = new ConfirmBatchController(confirmBatchUseCase);
const createVehicleController = new CreateVehicleController(createVehicleUseCase);
const loadBatchToVehicleController = new LoadBatchToVehicleController(loadBatchToVehicleUseCase);
const createTankController = new CreateTankController(createTankUseCase);
const receiveLoadToTankController = new ReceiveLoadToTankController(receiveLoadToTankUseCase);
const createYardController = new CreateYardController(createYardUseCase);
const receiveLoadToYardController = new ReceiveLoadToYardController(receiveLoadToYardUseCase);
const assignProductionToTankController = new AssignProductionToTankController(assignProductionToTankUseCase);
const createChemicalController = new CreateChemicalController(createChemicalUseCase);
const addChemicalToProcessController = new AddChemicalToProcessController(addChemicalToProcessUseCase);
//--Express & Setup
const app = express();
app.use(express.json()); // Middleware để parse JSON body
//4.Define Routes
// Lưu ý: bind(controller) là bắt buộc để giữ ngữ cảnh 'this'
app.post('/api/v1/harvest-batches', (req, res) => createBatchController.execute(req, res));
app.post('/api/v1/harvest-batches/:id/weigh', (req, res) => createWeighBatchController.execute(req, res));
app.patch('/api/v1/harvest-batches/:id/confirm', (req, res) => confirmBatchController.execute(req, res));
app.post('/api/v1/vehicles', (req, res) => createVehicleController.execute(req, res));
app.post('/api/v1/vehicles/:id/load', (req, res) => loadBatchToVehicleController.execute(req, res));
app.post('/api/v1/tanks', (req, res) => createTankController.execute(req, res));
app.post('/api/v1/load/:id/tanks', (req, res) => receiveLoadToTankController.execute(req, res));
app.post('/api/v1/yards', (req, res) => createYardController.execute(req, res));
app.post('/api/v1/load/:id/yards', (req, res) => receiveLoadToYardController.execute(req, res));
app.post('/api/v1/tanks/:id/assign-production', (req, res) => {assignProductionToTankController.execute(req, res);});
app.post('/api/v1/chemicals', (req, res) => {createChemicalController.execute(req, res);});
app.post('/api/v1/production/add-chemical', (req, res) => {addChemicalToProcessController.execute(req, res);});
//--START SERVER & DB CONNECTION

async function main() {
    // Test connection
    try {
        await prisma.$connect();
        console.log('✅ Database connected successfully');

        // Start Server (Express App listen...)
        const PORT = process.env['PORT'] || 3000;//ko chấp nhận process.env.PORT
        app.listen(PORT, () => {
            console.log(`🚀 Server is running on http://localhost:${PORT}`);
            console.log(`👉 Test POST at http://localhost:${PORT}/api/v1/harvest-batches`);
        });

        // app.listen(3000, ...)
        // --- TEST MANUAL NGAY TẠI ĐÂY ---
        // Giả lập Frontend gửi request
        // console.log('🚀 Executing CreateBatchUseCase...');

        // const newBatch = await createBatchUseCase.execute({
        //     workerId: '6af5650e-9fc7-46b9-bd96-d57a042e962f',
        //     shiftId: '1d91fd19-cf28-4e79-ab1e-47b734e7a6bb',
        //     latexType: 'NUOC',
        //     tappingAreaId: uuidv4(), // giả lập ID vùng khai thác
        // });

        // console.log('🎉 Batch Created:', newBatch);

        // Kiểm tra xem ID có được tạo ra không
        //     if (newBatch.id) console.log('✅ ID generated:', newBatch.id);
    } catch (error) {
        console.error('❌ Database connection failed', error);
        process.exit(1);
    }
    //
}

main();