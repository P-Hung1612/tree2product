// src/server.ts
import 'dotenv/config'; // Load .env
import { PrismaClient } from '@prisma/client';
// import { PrismaHarvestBatchRepository } from './infrastructure/database/prisma/repositories/PrismaHarvestBatchRepository';

// 1. Init Database Connection
const prisma = new PrismaClient();

// 2. Init Repositories (Inject Prisma)
// const harvestBatchRepo = new PrismaHarvestBatchRepository(prisma);

// 3. Init Use Cases (Inject Repo) - Phase 3 sẽ làm
// const createBatchUseCase = new CreateBatchUseCase(harvestBatchRepo);

// 4. Init Controllers (Inject Use Case) - Phase 4 sẽ làm

async function main() {
    // Test connection
    try {
        await prisma.$connect();
        console.log('✅ Database connected successfully');

        // Start Server (Express App listen...)
        // app.listen(3000, ...)
    } catch (error) {
        console.error('❌ Database connection failed', error);
        process.exit(1);
    }
}

main();